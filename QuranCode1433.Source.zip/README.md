QuranCode 1433
==============

                  QuranCode 1433
             Quran Research Platform
             (c) 2011-2014 Ali Adams
                www.qurancode.com

QuranCode is a numerical and similarity research tool for the Generous Quran

QuranCode is a free open-source software tool that is built to enable numerical and similarity research into the Quran.

QuranCode uses a 3-layer architecture with a fully OO object model.

Layer 1: Data Access Layer that read/write Quran text and meta files.

Layer 2: Business Logic Layer that provides a Client API for search by text/root/similarity/number and many valuation systems.

Layer 3: Presentation Layer that is a single-form user interface written in WinForms .NET 2.0 to stay compatible with old XP machines.

Derived projects can use the first two layers without any change and only replace the third layer on top of the Client API directly. Please feel free to use the software for any purpose GOD Almighty agrees with.

Be a guiding light!

Ali Adams
God > infinity
www.heliwave.com
